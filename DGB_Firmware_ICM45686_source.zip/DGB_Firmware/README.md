# DGB (Dual Gyro Button) Firmware: ICM-45686 version

Port of the BMI160 firmware to **two TDK InvenSense ICM-45686** IMUs on a
Waveshare RP2040-Zero. Same pins, same USB/DS4 emulation, same touch sensing.
Only the IMU driver changed (`icm45686_spi.*` replaces `bmi160_spi.*`).

## Wiring (identical to the BMI160 build)

Both boards share SCL, SDA and SA0, and each gets its own CS.

| RP2040-Zero | Board pin (both IMUs) | Notes |
| :--- | :--- | :--- |
| 3V3 | VCC | Power both boards |
| GND | GND | |
| GP2 | SCL | SPI clock |
| GP3 | SDA | SPI MOSI |
| GP0 | SA0 | SPI MISO (SDO) in SPI mode |
| GP1 | CS (sensor 1 only) | Chip select 1 |
| GP5 | CS (sensor 2 only) | Chip select 2 |
| GP9 / GP12 | Touch circuit | Unchanged |

INT1 / INT2 are not used.

## Changes from the BMI160 firmware

* New driver using TDK's register map (WHO_AM_I `0xE9`, soft reset, endianness
  check, low-noise accel + gyro, 1600 Hz ODR).
* **Both sensors now use the same gyro range (2000 dps).** The BMI160 build set
  different ranges on each sensor and then averaged raw counts.
* Serial prints each sensor's WHO_AM_I at boot so wiring problems are obvious.
* `IMU_SIGN_X/Y/Z` in `config.h` flip axis direction if needed.

## Build

Arduino IDE or arduino-cli with the Raspberry Pi Pico/RP2040 core by Earle
Philhower (built with 5.4.4), board **Waveshare RP2040-Zero**, USB Stack
**Adafruit TinyUSB**.

## Flash

Hold BOOT, plug in USB, drag `DGB_ICM45686_Dual.uf2` onto the `RPI-RP2` drive.
