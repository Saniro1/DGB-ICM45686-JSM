/**
 * @file config.h
 * @brief Hardware and Sensor Configuration for DGB (Dual Gyro Button) Firmware
 * Target MCU: Waveshare RP2040-Zero / Raspberry Pi RP2040
 * IMU Sensors: Dual TDK InvenSense ICM-45686 6-axis IMUs (High-Speed SPI)
 * USB Reporting: Sony DualShock 4 HID Emulation @ 1000 Hz
 *
 * This is the ICM-45686 port of the original BMI160 firmware. Pin assignments
 * are identical to the BMI160 version, so existing wiring carries over.
 */

#ifndef CONFIG_H_
#define CONFIG_H_

#include <stdint.h>
#include <stdbool.h>
#include <Arduino.h>

// ==============================================================================
// 1. HARDWARE SPI PINOUT (RP2040 SPI0)  -- unchanged from the BMI160 build
// ==============================================================================
#define PIN_SPI_MISO            0   // GP0: Master In Slave Out (board pin SA0 / SDO)
#define PIN_SPI_CS1             1   // GP1: Chip Select for Sensor 1
#define PIN_SPI_SCK             2   // GP2: Serial Clock (board pin SCL)
#define PIN_SPI_MOSI            3   // GP3: Master Out Slave In (board pin SDA / SDI)
#define PIN_SPI_CS2             5   // GP5: Chip Select for Sensor 2

#define SPI_CLOCK_SPEED_HZ      10000000  // 10 MHz (ICM-45686 supports up to 24 MHz)

// ==============================================================================
// 2. CAPACITIVE AUTO TOUCH DETECTION PINOUT
// ==============================================================================
// RC charge-time capacitive touch detection circuit.
// Connect a 1MΩ - 10MΩ resistor between PIN_TOUCH_SEND and PIN_TOUCH_RECV.
// Connect conductive copper tape / touch foil to PIN_TOUCH_RECV.
#define PIN_TOUCH_SEND          9   // GP9: Pulse Send Pin (OUTPUT)
#define PIN_TOUCH_RECV          12  // GP12: Capacitive Sensor Foil Pin (INPUT)

// Touch threshold: higher value requires stronger contact
#define TOUCH_THRESHOLD_SAMPLES 35  // Cycle counter threshold for touch contact
#define TOUCH_HYSTERESIS        5   // Noise rejection margin

// ==============================================================================
// 3. ICM-45686 REGISTER MAP (values taken from TDK's open-source driver,
//    tdk-invn-oss/motion.arduino.ICM45686, inv_imu_regmap_le.h / inv_imu_defs.h)
// ==============================================================================
// Direct registers (SPI: bit 7 = 1 for read, 0 for write)
#define ICM_REG_ACCEL_DATA_X1   0x00  // Start of 14-byte block: accel XYZ, gyro XYZ, temp
#define ICM_REG_PWR_MGMT0       0x10  // [1:0] accel mode, [3:2] gyro mode
#define ICM_REG_INT1_STATUS0    0x19  // bit 7 = RESET_DONE
#define ICM_REG_ACCEL_CONFIG0   0x1B  // [3:0] ODR, [6:4] full-scale
#define ICM_REG_GYRO_CONFIG0    0x1C  // [3:0] ODR, [7:4] full-scale
#define ICM_REG_WHO_AM_I        0x72
#define ICM_REG_IREG_ADDR_15_8  0x7C  // Indirect (MREG) access: address high, then low (0x7D)
#define ICM_REG_IREG_DATA       0x7E  // Indirect (MREG) access: data
#define ICM_REG_MISC2           0x7F  // bit 1 = SOFT_RST

// Indirect register holding the data endianness select (bit 1: 1 = big endian)
#define ICM_MREG_SREG_CTRL      0xA267

#define ICM_WHO_AM_I_VALUE      0xE9  // ICM-45686
#define ICM_SOFT_RST_BIT        0x02
#define ICM_RESET_DONE_BIT      0x80
#define ICM_SREG_BIG_ENDIAN_BIT 0x02

// PWR_MGMT0: accel low-noise (3) | gyro low-noise (3) << 2
#define ICM_PWR_ACCEL_GYRO_LN   0x0F

// ODR codes (same table for accel and gyro)
#define ICM_ODR_800_HZ          0x6
#define ICM_ODR_1600_HZ         0x5
#define ICM_ODR_3200_HZ         0x4

// Full-scale codes
#define ICM_GYRO_FS_2000_DPS    1
#define ICM_GYRO_FS_1000_DPS    2
#define ICM_GYRO_FS_500_DPS     3
#define ICM_ACCEL_FS_16G        1
#define ICM_ACCEL_FS_8G         2

// ==============================================================================
// 4. SENSOR TUNING
// ==============================================================================
// BOTH sensors use the same scale. (The BMI160 build configured the two sensors
// with different gyro ranges but averaged raw counts, which skews the result.)
// 2000 dps = 16.4 LSB/dps, close to a real DualShock 4 gyro scale.
#define IMU_GYRO_ODR            ICM_ODR_1600_HZ
#define IMU_GYRO_FS             ICM_GYRO_FS_2000_DPS
#define IMU_ACCEL_ODR           ICM_ODR_1600_HZ
#define IMU_ACCEL_FS            ICM_ACCEL_FS_16G

// Axis polarity. Flip a sign to -1 if an axis moves the wrong way after
// swapping to this board. Applied after both sensors are averaged, so both
// sensors must be mounted in the same orientation.
#define IMU_SIGN_X              1
#define IMU_SIGN_Y              1
#define IMU_SIGN_Z              1

// Output Reporting:
#define USB_POLL_RATE_HZ        1000  // 1000 Hz (1 ms interval) DualShock 4 HID report
#define CALIBRATION_SAMPLES     1000  // Samples collected at boot while stationary

#endif // CONFIG_H_
