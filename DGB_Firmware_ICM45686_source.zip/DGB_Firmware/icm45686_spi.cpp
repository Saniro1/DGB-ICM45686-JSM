/**
 * @file icm45686_spi.cpp
 * @brief Dual TDK InvenSense ICM-45686 IMU SPI Driver Implementation
 *
 * Register addresses, bit positions and the soft-reset / endianness handling
 * follow TDK's open-source driver (tdk-invn-oss/motion.arduino.ICM45686).
 */

#include "icm45686_spi.h"
#include <SPI.h>

DualIcm45686 imu;

DualIcm45686::DualIcm45686() {
  bias1 = {0, 0, 0};
  bias2 = {0, 0, 0};
  _cs[0] = PIN_SPI_CS1;
  _cs[1] = PIN_SPI_CS2;
  _bigEndian[0] = _bigEndian[1] = false;
  _ok[0] = _ok[1] = false;
  _whoAmI[0] = _whoAmI[1] = 0;
}

void DualIcm45686::writeRegister(uint8_t csPin, uint8_t reg, uint8_t val) {
  SPI.beginTransaction(SPISettings(SPI_CLOCK_SPEED_HZ, MSBFIRST, SPI_MODE0));
  digitalWrite(csPin, LOW);
  SPI.transfer(reg & 0x7F); // Bit 7 = 0 for write
  SPI.transfer(val);
  digitalWrite(csPin, HIGH);
  SPI.endTransaction();
}

uint8_t DualIcm45686::readRegister(uint8_t csPin, uint8_t reg) {
  SPI.beginTransaction(SPISettings(SPI_CLOCK_SPEED_HZ, MSBFIRST, SPI_MODE0));
  digitalWrite(csPin, LOW);
  SPI.transfer(reg | 0x80); // Bit 7 = 1 for read
  uint8_t val = SPI.transfer(0x00);
  digitalWrite(csPin, HIGH);
  SPI.endTransaction();
  return val;
}

// Indirect (MREG) read of a single byte, as done in TDK's inv_imu_transport.c:
// write the 16-bit address to IREG_ADDR_15_8/7_0, then read IREG_DATA, with
// a few microseconds between accesses.
uint8_t DualIcm45686::readIndirect(uint8_t csPin, uint16_t addr) {
  delayMicroseconds(4);
  SPI.beginTransaction(SPISettings(SPI_CLOCK_SPEED_HZ, MSBFIRST, SPI_MODE0));
  digitalWrite(csPin, LOW);
  SPI.transfer(ICM_REG_IREG_ADDR_15_8 & 0x7F);
  SPI.transfer((uint8_t)(addr >> 8));
  SPI.transfer((uint8_t)(addr & 0xFF));
  digitalWrite(csPin, HIGH);
  SPI.endTransaction();
  delayMicroseconds(4);
  return readRegister(csPin, ICM_REG_IREG_DATA);
}

bool DualIcm45686::initSensor(int idx) {
  const uint8_t cs = _cs[idx];

  // 1. Identify the chip (one retry, the first transaction after power-up can be lost)
  uint8_t who = readRegister(cs, ICM_REG_WHO_AM_I);
  if (who != ICM_WHO_AM_I_VALUE) {
    delay(5);
    who = readRegister(cs, ICM_REG_WHO_AM_I);
  }
  _whoAmI[idx] = who;
  if (who != ICM_WHO_AM_I_VALUE) {
    return false;
  }

  // 2. Soft reset, then wait for RESET_DONE (read of INT1_STATUS0 clears it)
  writeRegister(cs, ICM_REG_MISC2, ICM_SOFT_RST_BIT);
  delay(2);
  bool resetDone = false;
  for (int i = 0; i < 20 && !resetDone; i++) {
    resetDone = (readRegister(cs, ICM_REG_INT1_STATUS0) & ICM_RESET_DONE_BIT) != 0;
    if (!resetDone) delay(1);
  }
  if (!resetDone) {
    return false;
  }

  // 3. Data byte order (SREG_CTRL bit 1: 1 = big endian)
  _bigEndian[idx] = (readIndirect(cs, ICM_MREG_SREG_CTRL) & ICM_SREG_BIG_ENDIAN_BIT) != 0;

  // 4. Full scale and output data rate while the sensors are still off
  const uint8_t gyroCfg  = (uint8_t)((IMU_GYRO_FS << 4) | IMU_GYRO_ODR);
  const uint8_t accelCfg = (uint8_t)((IMU_ACCEL_FS << 4) | IMU_ACCEL_ODR);
  writeRegister(cs, ICM_REG_GYRO_CONFIG0, gyroCfg);
  writeRegister(cs, ICM_REG_ACCEL_CONFIG0, accelCfg);

  // 5. Accel + gyro into low-noise mode, then wait out the startup time
  //    (accel ~10 ms, gyro ~70 ms per TDK's driver)
  writeRegister(cs, ICM_REG_PWR_MGMT0, ICM_PWR_ACCEL_GYRO_LN);
  delay(100);

  // 6. Read back to confirm the configuration took
  if (readRegister(cs, ICM_REG_GYRO_CONFIG0) != gyroCfg) return false;
  if (readRegister(cs, ICM_REG_ACCEL_CONFIG0) != accelCfg) return false;
  if ((readRegister(cs, ICM_REG_PWR_MGMT0) & 0x0F) != ICM_PWR_ACCEL_GYRO_LN) return false;

  return true;
}

bool DualIcm45686::begin() {
  // Set CS pins as OUTPUT and HIGH
  pinMode(PIN_SPI_CS1, OUTPUT);
  pinMode(PIN_SPI_CS2, OUTPUT);
  digitalWrite(PIN_SPI_CS1, HIGH);
  digitalWrite(PIN_SPI_CS2, HIGH);
  delay(10);

  // Initialize RP2040 SPI0 pins (chip selects are driven manually)
  SPI.setRX(PIN_SPI_MISO);
  SPI.setSCK(PIN_SPI_SCK);
  SPI.setTX(PIN_SPI_MOSI);
  SPI.begin();

  _ok[0] = initSensor(0);
  _ok[1] = initSensor(1);

  delay(50);
  return _ok[0] && _ok[1];
}

void DualIcm45686::readSensorData(int idx, ImuRawData &data) {
  const uint8_t cs = _cs[idx];
  uint8_t raw[12];

  SPI.beginTransaction(SPISettings(SPI_CLOCK_SPEED_HZ, MSBFIRST, SPI_MODE0));
  digitalWrite(cs, LOW);
  SPI.transfer(ICM_REG_ACCEL_DATA_X1 | 0x80); // Burst read from 0x00
  for (int i = 0; i < 12; i++) {
    raw[i] = SPI.transfer(0x00);
  }
  digitalWrite(cs, HIGH);
  SPI.endTransaction();

  // Layout: accel X,Y,Z (6 bytes) then gyro X,Y,Z (6 bytes). Byte order depends on SREG_CTRL.
  int16_t v[6];
  for (int i = 0; i < 6; i++) {
    const uint8_t b0 = raw[2 * i];
    const uint8_t b1 = raw[2 * i + 1];
    v[i] = _bigEndian[idx] ? (int16_t)((b0 << 8) | b1) : (int16_t)((b1 << 8) | b0);
  }

  data.ax = v[0];
  data.ay = v[1];
  data.az = v[2];
  data.gx = v[3];
  data.gy = v[4];
  data.gz = v[5];
}

void DualIcm45686::readFusedMotion(ImuRawData &fused) {
  ImuRawData d1, d2;
  readSensorData(0, d1);
  readSensorData(1, d2);

  // Apply zero-rate calibration offsets and average in 32-bit to avoid overflow
  const int32_t gx = ((int32_t)d1.gx - bias1.gx + (int32_t)d2.gx - bias2.gx) / 2;
  const int32_t gy = ((int32_t)d1.gy - bias1.gy + (int32_t)d2.gy - bias2.gy) / 2;
  const int32_t gz = ((int32_t)d1.gz - bias1.gz + (int32_t)d2.gz - bias2.gz) / 2;

  fused.gx = (int16_t)(gx * IMU_SIGN_X);
  fused.gy = (int16_t)(gy * IMU_SIGN_Y);
  fused.gz = (int16_t)(gz * IMU_SIGN_Z);

  fused.ax = (int16_t)(((int32_t)d1.ax + d2.ax) / 2 * IMU_SIGN_X);
  fused.ay = (int16_t)(((int32_t)d1.ay + d2.ay) / 2 * IMU_SIGN_Y);
  fused.az = (int16_t)(((int32_t)d1.az + d2.az) / 2 * IMU_SIGN_Z);
}

void DualIcm45686::calibrateRestingOffsets() {
  int64_t sumGx1 = 0, sumGy1 = 0, sumGz1 = 0;
  int64_t sumGx2 = 0, sumGy2 = 0, sumGz2 = 0;

  for (int i = 0; i < CALIBRATION_SAMPLES; i++) {
    ImuRawData d1, d2;
    readSensorData(0, d1);
    readSensorData(1, d2);

    sumGx1 += d1.gx;
    sumGy1 += d1.gy;
    sumGz1 += d1.gz;

    sumGx2 += d2.gx;
    sumGy2 += d2.gy;
    sumGz2 += d2.gz;

    delayMicroseconds(1000);
  }

  bias1.gx = (int32_t)(sumGx1 / CALIBRATION_SAMPLES);
  bias1.gy = (int32_t)(sumGy1 / CALIBRATION_SAMPLES);
  bias1.gz = (int32_t)(sumGz1 / CALIBRATION_SAMPLES);

  bias2.gx = (int32_t)(sumGx2 / CALIBRATION_SAMPLES);
  bias2.gy = (int32_t)(sumGy2 / CALIBRATION_SAMPLES);
  bias2.gz = (int32_t)(sumGz2 / CALIBRATION_SAMPLES);
}
