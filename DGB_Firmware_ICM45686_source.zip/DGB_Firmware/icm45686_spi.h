/**
 * @file icm45686_spi.h
 * @brief Dual TDK InvenSense ICM-45686 IMU SPI Driver
 */

#ifndef ICM45686_SPI_H_
#define ICM45686_SPI_H_

#include "config.h"

struct ImuRawData {
  int16_t gx;
  int16_t gy;
  int16_t gz;
  int16_t ax;
  int16_t ay;
  int16_t az;
};

struct ImuBiasOffsets {
  int32_t gx;
  int32_t gy;
  int32_t gz;
};

class DualIcm45686 {
public:
  DualIcm45686();

  // Initializes both sensors. Returns true only if both answered with the
  // ICM-45686 WHO_AM_I value and accepted their configuration.
  bool begin();

  void writeRegister(uint8_t csPin, uint8_t reg, uint8_t val);
  uint8_t readRegister(uint8_t csPin, uint8_t reg);

  // idx: 0 = sensor 1 (CS1), 1 = sensor 2 (CS2)
  void readSensorData(int idx, ImuRawData &data);
  void readFusedMotion(ImuRawData &fused);
  void calibrateRestingOffsets();

  bool sensorOk(int idx) const { return _ok[idx]; }
  uint8_t whoAmI(int idx) const { return _whoAmI[idx]; }

  ImuBiasOffsets bias1;
  ImuBiasOffsets bias2;

private:
  bool initSensor(int idx);
  uint8_t readIndirect(uint8_t csPin, uint16_t addr);

  uint8_t _cs[2];
  bool _bigEndian[2];
  bool _ok[2];
  uint8_t _whoAmI[2];
};

extern DualIcm45686 imu;

#endif // ICM45686_SPI_H_
